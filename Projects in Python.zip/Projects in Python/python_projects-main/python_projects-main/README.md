### Projects

Here you can find all the source code to the projects taught in the Udemy course.

